const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const questionsPlayer = [
"What is your full name?","How old are you?","What city or area do you live in?","What position(s) do you play?",
"What is your preferred foot?","How long have you played organized soccer?","What team or club did you most recently play for?",
"What level have you played at?","What are your biggest strengths as a player?","What parts of your game are you working to improve?",
"How would you describe your playing style?","What is your current availability for training?","Are you available for weekend matches?",
"Do you have reliable transportation to matches and training?","What makes you interested in joining our team?",
"What would you bring to the team beyond your playing ability?","How do you respond to feedback from coaches or teammates?",
"Describe a challenging moment in soccer and how you handled it.","Are there any injuries or limitations that affect your participation? (Share only what is relevant.)",
"Anything else you would like us to know?"
];
const questionsPartner = [
"What is your full name and role?","What is your company or organization name?","What is your organization's website or social profile?",
"What industry or community do you serve?","Briefly describe your organization.","Why are you interested in partnering with our team?",
"What type of partnership are you proposing?","What goals would you like this partnership to achieve?",
"Who is your target audience?","What value can you offer our team or players?","What value would you hope to receive from the partnership?",
"Are you proposing financial sponsorship, products, services, or another arrangement?","What budget or contribution range are you considering, if applicable?",
"What partnership duration do you have in mind?","Would you like brand placement on team materials or kits?",
"Can you support match-day activities or events? If so, how?","Have you partnered with sports teams before? Describe briefly.",
"What resources or people would be involved from your side?","What timeline would you like to work toward?",
"Is there anything else we should know about your proposal?"
];
let currentUser = null, isAdmin = false, adminTab = "applications", rosterCache = [];
const initialMatches = [
{day:"24",month:"OCT",opponent:"INTER SC",venue:"Randalls Field 85",kind:"UPCOMING"},
{day:"25",month:"OCT",opponent:"LOS PRIMOS",venue:"Randalls Field 85",kind:"UPCOMING"}
];
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showPage(name){
  const valid=["home","roster","news","schedule","login","apply","player-application","partner-application","admin"];
  if(!valid.includes(name))name="home";
  $$(".page").forEach(p=>p.classList.remove("active"));
  $("#page-"+name)?.classList.add("active");
  $$("nav a").forEach(a=>a.classList.toggle("active",a.dataset.page===name));
  window.scrollTo({top:0,behavior:"smooth"});
  if(name==="login")renderGoogleButton();
  if(name==="roster")loadRoster();
  if(name==="news")loadNews();
  if(name==="schedule")renderSchedule();
  if(name==="admin"){if(isAdmin)loadAdmin();else showPage("login");}
}
document.addEventListener("click",e=>{
  const p=e.target.closest("[data-page]"); if(p){e.preventDefault();showPage(p.dataset.page);}
  const tab=e.target.closest("[data-admin-tab]");if(tab){adminTab=tab.dataset.adminTab;loadAdmin();}
  const decision=e.target.closest("[data-decision]");if(decision)decideApplication(decision.dataset.id,decision.dataset.decision);
  const del=e.target.closest("[data-delete-roster]");if(del)deleteRoster(del.dataset.deleteRoster);
  const delNews=e.target.closest("[data-delete-news]");if(delNews)deleteNews(delNews.dataset.deleteNews);
  const answers=e.target.closest("[data-show-answers]");if(answers)$("#answers-"+answers.dataset.showAnswers)?.classList.toggle("hidden");
});
async function api(url,opts={}){
 const r=await fetch(url,{...opts,headers:{"Content-Type":"application/json",...(opts.headers||{})},credentials:"same-origin"});
 const data=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(data.error||"Something went wrong.");
 return data;
}
async function refreshMe(){
 try{const d=await api("/api/me");currentUser=d.user;isAdmin=d.isAdmin;}catch{}
 updateAccount();
}
function updateAccount(){
 const login=$("#loginBtn"),account=$("#accountBtn");
 if(currentUser){login.classList.add("hidden");account.classList.remove("hidden");account.textContent=(isAdmin?"ADMIN · ":"")+currentUser.name.split(" ")[0]+" ▾";}
 else{login.classList.remove("hidden");account.classList.add("hidden");}
}
$("#loginBtn").addEventListener("click",()=>showPage("login"));
$("#accountBtn").addEventListener("click",async()=>{if(isAdmin){showPage("admin");return;}if(confirm("Sign out of your player account?")){await api("/api/logout",{method:"POST"});currentUser=null;isAdmin=false;updateAccount();}});
async function renderGoogleButton(){
 const msg=$("#loginMessage");msg.textContent="";
 try{
  const cfg=await api("/api/config");
  if(!cfg.googleClientId){msg.textContent="Google sign-in needs setup by the site administrator. See README.md.";msg.classList.add("error");return;}
  const draw=()=>{if(!window.google?.accounts?.id){setTimeout(draw,250);return;}
   google.accounts.id.initialize({client_id:cfg.googleClientId,callback:async response=>{
    try{const d=await api("/api/auth/google",{method:"POST",body:JSON.stringify({credential:response.credential})});currentUser=d.user;isAdmin=d.isAdmin;updateAccount();msg.classList.remove("error");msg.textContent="Signed in successfully.";setTimeout(()=>showPage(isAdmin?"admin":"roster"),500);}
    catch(e){msg.textContent=e.message;msg.classList.add("error");}
   }});
   $("#googleButton").innerHTML="";
   google.accounts.id.renderButton($("#googleButton"),{theme:"filled_black",size:"large",shape:"rectangular",text:"continue_with",width:270});
  };draw();
 }catch(e){msg.textContent=e.message;msg.classList.add("error");}
}
async function loadRoster(){
 try{rosterCache=await api("/api/roster");$("#rosterList").innerHTML=rosterCache.map(p=>`<article class="player-card"><span class="player-number">${esc(p.number||"—")}</span><h3>${esc(p.name)}</h3><p>${esc((p.position||"PLAYER").toUpperCase())}</p>${p.instagram?`<a target="_blank" rel="noopener" href="${esc(p.instagram)}">INSTAGRAM ↗</a>`:""}</article>`).join("");$("#rosterEmpty").classList.toggle("hidden",rosterCache.length>0);}
 catch(e){$("#rosterList").innerHTML=`<p class="empty">${esc(e.message)}</p>`;}
}
async function loadNews(){
 try{const list=await api("/api/news");const html=list.map(n=>`<article class="news-card"><div><span class="tag">CLUB UPDATE</span><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p></div><time>${esc((n.created_at||"").slice(0,10))}</time></article>`).join("");$("#allNews").innerHTML=html||'<p class="empty">No news yet.</p>';}
 catch(e){$("#allNews").innerHTML=`<p class="empty">${esc(e.message)}</p>`;}
}
function renderMatches(){
 return initialMatches.map(m=>`<div class="match-card"><div class="match-date"><b>${m.day}</b><small>${m.month} 2026</small></div><div class="match-info"><small>UPCOMING FIXTURE</small><h3>${m.opponent}</h3><small>${m.venue}</small></div><span class="match-label">${m.kind}</span></div>`).join("");
}
function renderSchedule(){
 $("#scheduleList").innerHTML=`<article class="schedule-row"><div class="date">OCT 19</div><div><h3>NY UNITED SC</h3><p>Randalls · Final score</p></div><span class="status">WON 5–3</span></article>`+initialMatches.map(m=>`<article class="schedule-row"><div class="date">OCT ${m.day}</div><div><h3>${m.opponent}</h3><p>${m.venue}</p></div><span class="status">UPCOMING</span></article>`).join("");
}
function questionMarkup(items){return items.map((q,i)=>`<div class="question"><span class="q-number">QUESTION ${String(i+1).padStart(2,"0")} / 20</span><label for="q${i}">${esc(q)} *</label><textarea id="q${i}" name="q${i}" required maxlength="2000" placeholder="Your answer..."></textarea></div>`).join("");}
$("#playerQuestions").innerHTML=questionMarkup(questionsPlayer);
$("#partnerQuestions").innerHTML=questionMarkup(questionsPartner);
function formAnswers(form){return [...form.querySelectorAll(".question textarea")].map(x=>x.value.trim());}
async function submitApplication(form,type,msgId){
 const msg=$(msgId);msg.classList.remove("error");msg.textContent="Submitting...";
 try{
  const fd=new FormData(form),data={type,name:fd.get("name"),email:fd.get("email"),instagram:fd.get("instagram")||"",answers:formAnswers(form)};
  const result=await api("/api/applications",{method:"POST",body:JSON.stringify(data)});
  form.reset();msg.textContent=`Application submitted successfully. Reference #${result.id}. Keep an eye on your email for updates.`;
 }catch(e){msg.textContent=e.message;msg.classList.add("error");}
}
$("#playerForm").addEventListener("submit",e=>{e.preventDefault();submitApplication(e.currentTarget,"player","#playerFormMessage");});
$("#partnerForm").addEventListener("submit",e=>{e.preventDefault();submitApplication(e.currentTarget,"partnership","#partnerFormMessage");});
async function loadAdmin(){
 if(!isAdmin){$("#adminContent").innerHTML='<p class="empty">Administrator access only. Sign in with the configured admin Google account.</p>';return;}
 $$(".admin-tabs button").forEach(b=>b.classList.toggle("active",b.dataset.adminTab===adminTab));
 const root=$("#adminContent");root.innerHTML='<p class="message">Loading…</p>';
 try{
  if(adminTab==="applications"){
   const items=await api("/api/admin/applications");
   root.innerHTML=items.length?items.map(a=>`<article class="admin-item"><div class="admin-item-head"><div><h3>${esc(a.name)} <span style="font-size:12px;color:#a2ada2">· ${a.type==="player"?"Player":"Partnership"}</span></h3><p>${esc(a.email)}${a.instagram?` · <a target="_blank" rel="noopener" href="${esc(a.instagram)}">Instagram ↗</a>`:""}</p><p>Submitted ${esc(a.submitted_at||"")}</p></div><span class="status-pill">${esc(a.status)}</span></div><button class="mini-btn" data-show-answers="${a.id}">VIEW 20 ANSWERS</button><div id="answers-${a.id}" class="answers hidden">${a.answers.map((ans,i)=>`<p><b>${i+1}. ${esc(ans)}</b></p>`).join("")}</div>${a.status==="pending"?`<div class="admin-actions"><button class="mini-btn accept" data-id="${a.id}" data-decision="accepted">ACCEPT + EMAIL</button><button class="mini-btn deny" data-id="${a.id}" data-decision="denied">DENY + EMAIL</button></div>`:""}</article>`).join(""):'<p class="empty">No applications have been submitted yet.</p>';
  }else if(adminTab==="roster"){
   const roster=await api("/api/roster");
   root.innerHTML=`<form id="addPlayerForm" class="admin-form"><h3>ADD A PLAYER</h3><label>Player name *<input name="name" required></label><label>Jersey number<input name="number"></label><label>Position<input name="position" placeholder="Forward, midfielder…"></label><label>Player email<input name="email" type="email"></label><label class="wide">Instagram URL<input name="instagram" type="url"></label><button class="btn btn-lime" type="submit">ADD TO ROSTER +</button><p id="adminRosterMessage" class="message wide"></p></form>`+
   (roster.map(p=>`<article class="admin-item"><div class="admin-item-head"><div><h3>#${esc(p.number||"—")} ${esc(p.name)}</h3><p>${esc(p.position||"Player")} · ${esc(p.instagram||"No Instagram")}</p></div><button class="mini-btn deny" data-delete-roster="${p.id}">REMOVE</button></div></article>`).join("")||'<p class="empty">No players yet. Add the first player above.</p>');
   $("#addPlayerForm").addEventListener("submit",async e=>{e.preventDefault();const f=e.currentTarget,d=Object.fromEntries(new FormData(f));try{await api("/api/admin/roster",{method:"POST",body:JSON.stringify(d)});loadAdmin();}catch(err){$("#adminRosterMessage").textContent=err.message;$("#adminRosterMessage").classList.add("error");}});
  }else{
   const news=await api("/api/news");
   root.innerHTML=`<form id="addNewsForm" class="admin-form"><h3>PUBLISH NEWS</h3><label class="wide">Headline *<input name="title" required maxlength="200"></label><label class="wide">Story / details *<textarea name="body" required rows="4"></textarea></label><button class="btn btn-lime" type="submit">PUBLISH UPDATE ↗</button><p id="adminNewsMessage" class="message wide"></p></form>`+
   news.map(n=>`<article class="admin-item"><div class="admin-item-head"><div><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p></div><button class="mini-btn deny" data-delete-news="${n.id}">DELETE</button></div></article>`).join("");
   $("#addNewsForm").addEventListener("submit",async e=>{e.preventDefault();const f=e.currentTarget,d=Object.fromEntries(new FormData(f));try{await api("/api/admin/news",{method:"POST",body:JSON.stringify(d)});loadAdmin();}catch(err){$("#adminNewsMessage").textContent=err.message;$("#adminNewsMessage").classList.add("error");}});
  }
 }catch(e){root.innerHTML=`<p class="empty">${esc(e.message)}</p>`;}
}
async function decideApplication(id,status){
 const verb=status==="accepted"?"accept":"deny";
 if(!confirm(`Are you sure you want to ${verb} this application? An email will be sent if email delivery is configured.`))return;
 try{const d=await api(`/api/admin/applications/${id}/decision`,{method:"POST",body:JSON.stringify({status})});await loadAdmin();if(d.emailWarning)alert(d.emailWarning);else alert("Decision saved and email sent.");}
 catch(e){alert(e.message);}
}
async function deleteRoster(id){if(!confirm("Remove this player from the roster?"))return;try{await api(`/api/admin/roster/${id}`,{method:"DELETE"});loadAdmin();}catch(e){alert(e.message);}}
async function deleteNews(id){if(!confirm("Delete this news item?"))return;try{await api(`/api/admin/news/${id}`,{method:"DELETE"});loadAdmin();}catch(e){alert(e.message);}}
async function init(){
 await refreshMe();
 try{
  const news=await api("/api/news");
  $("#homeNews").innerHTML=news.slice(0,3).map(n=>`<article class="news-card"><div><span class="tag">CLUB UPDATE</span><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p></div><time>${esc((n.created_at||"").slice(0,10))}</time></article>`).join("");
 }catch{}
 $("#nextMatches").innerHTML=renderMatches();
}
init();
