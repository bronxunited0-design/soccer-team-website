# Clubhouse — Soccer Team Portal

A starter full-stack website for a soccer club. Includes public roster/news/schedule, Google sign-in, admin-only roster and news management, player applications, partnership applications, and acceptance/denial email delivery.

## Important: customize before launch

The club name, badge, and colors are placeholders because the team's actual name/logo were not supplied. The current visual uses a generic “Clubhouse / C+” identity. Update `public/index.html` and `public/styles.css` when you have the real logo and team name.

## Run locally

Requires Node.js 18 or newer.

1. Extract this folder.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Configure Google sign-in and SMTP (steps below).
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Configure Google sign-in

1. Open the Google Cloud Console: https://console.cloud.google.com/
2. Create/select a project and configure the OAuth consent screen.
3. Create an OAuth client ID of type **Web application**.
4. Add your local origin under Authorized JavaScript origins: `http://localhost:3000`.
5. Add the deployed site's origin when you deploy it.
6. Put the OAuth client ID in `GOOGLE_CLIENT_ID` in `.env`.
7. Put the one administrator Google email in `ADMIN_EMAIL`.

Only the account whose verified email matches `ADMIN_EMAIL` can use admin API endpoints. Never put a private secret in frontend JavaScript.

## Configure automatic decision emails

For Gmail SMTP, enable 2-Step Verification on the sending Google account and create a Google App Password: https://myaccount.google.com/apppasswords

Set `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=465`, `SMTP_SECURE=true`, `SMTP_USER`, `SMTP_PASS`, and `MAIL_FROM` in `.env`. Use an app password, not the normal account password. A decision is saved even if mail delivery fails; the admin UI displays a warning.

For a public production website, a transactional provider such as Resend, Postmark, or SendGrid may be more reliable than personal Gmail SMTP.

## Deployment

Deploy to a Node.js host that supports persistent disk storage (the SQLite database is `team-portal.sqlite`). Add all `.env` values as the host's environment variables, set `NODE_ENV=production`, and use HTTPS. If your host has an ephemeral filesystem, use a managed database or persistent volume before relying on stored roster/application data.

For production, replace the default session store with a persistent session store, use a strong random `SESSION_SECRET`, add rate limiting and CSRF protection, set up database backups, and publish a privacy policy. Do not use this development starter as-is for sensitive or high-volume recruitment.

## Features

- Public roster view; public users cannot edit roster.
- Google Identity Services sign-in; verified Google identity is checked server-side.
- Admin-only APIs for roster/news/application review.
- Separate player and partnership forms, each with 20 required questions.
- Player application requires an Instagram profile URL.
- Accept/deny actions attempt to email the applicant.
- Initial result/news and fixture details for October 2026.

## Seed content

- Won 5–3 against NY UNITED SC at Randalls on October 19, 2026.
- October 24, 2026: INTER SC, Randalls Field 85.
- October 25, 2026: Los Primos, Randalls Field 85.

The roster starts empty so the administrator can add the real players.
