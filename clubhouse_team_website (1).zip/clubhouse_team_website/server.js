require("dotenv").config();
const express = require("express");
const session = require("express-session");
const { OAuth2Client } = require("google-auth-library");
const nodemailer = require("nodemailer");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "team-portal.sqlite"));
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS roster (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, number TEXT DEFAULT '',
 position TEXT DEFAULT '', instagram TEXT DEFAULT '', email TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS news (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, name TEXT NOT NULL,
 email TEXT NOT NULL, instagram TEXT DEFAULT '', answers TEXT NOT NULL,
 status TEXT DEFAULT 'pending', submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
 reviewed_at TEXT DEFAULT NULL
);
`);
const newsCount = db.prepare("SELECT COUNT(*) AS n FROM news").get().n;
if (!newsCount) {
  const insert = db.prepare("INSERT INTO news (title, body) VALUES (?, ?)");
  insert.run("A 5–3 win against NY UNITED SC", "We won 5–3 against NY UNITED SC at Randalls on October 19, 2026.");
  insert.run("Next match: INTER SC", "October 24, 2026 · Randalls Field 85");
  insert.run("Next match: Los Primos", "October 25, 2026 · Randalls Field 85");
}

app.use(express.json({ limit: "200kb" }));
app.use(session({
  name: "team.sid",
  secret: process.env.SESSION_SECRET || "change-this-before-deploying",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 12 }
}));
app.use(express.static(path.join(__dirname, "public")));

const adminEmail = () => (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in with Google first." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in first." });
  if (!adminEmail() || req.session.user.email.toLowerCase() !== adminEmail())
    return res.status(403).json({ error: "Administrator access only." });
  next();
}
function mailer() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || "true") === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

app.get("/api/config", (_, res) => res.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || "" }));
app.get("/api/me", (req, res) => {
  const user = req.session.user || null;
  res.json({ user, isAdmin: !!user && !!adminEmail() && user.email.toLowerCase() === adminEmail() });
});
app.post("/api/auth/google", async (req, res) => {
  try {
    if (!process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error: "Google sign-in has not been configured yet." });
    const ticket = await googleClient.verifyIdToken({ idToken: req.body.credential, audience: process.env.GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p || !p.email || !p.email_verified) return res.status(401).json({ error: "Use a verified Google account." });
    req.session.user = { email: p.email, name: p.name || p.email, picture: p.picture || "" };
    res.json({ user: req.session.user, isAdmin: p.email.toLowerCase() === adminEmail() });
  } catch (e) { res.status(401).json({ error: "Google sign-in could not be verified. Please try again." }); }
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/roster", (_, res) => res.json(db.prepare("SELECT id,name,number,position,instagram FROM roster ORDER BY CAST(number AS INTEGER), name").all()));
app.get("/api/news", (_, res) => res.json(db.prepare("SELECT id,title,body,created_at FROM news ORDER BY id DESC").all()));
app.get("/api/applications/mine", requireLogin, (req, res) => {
  res.json(db.prepare("SELECT id,type,status,submitted_at FROM applications WHERE lower(email)=lower(?) ORDER BY id DESC").all(req.session.user.email));
});
app.post("/api/applications", (req, res) => {
  const { type, name, email, instagram, answers } = req.body || {};
  if (!["player", "partnership"].includes(type)) return res.status(400).json({ error: "Invalid application type." });
  if (!String(name || "").trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "")))
    return res.status(400).json({ error: "Enter your name and a valid email address." });
  if (type === "player" && !/^https?:\/\/(www\.)?instagram\.com\/[A-Za-z0-9._]+\/?$/i.test(String(instagram || "").trim()))
    return res.status(400).json({ error: "Enter a valid Instagram profile link." });
  if (!Array.isArray(answers) || answers.length !== 20 || answers.some(a => !String(a || "").trim()))
    return res.status(400).json({ error: "Please answer all 20 questions." });
  const info = db.prepare("INSERT INTO applications (type,name,email,instagram,answers) VALUES (?,?,?,?,?)")
    .run(type, String(name).trim().slice(0,150), String(email).trim().slice(0,254), String(instagram || "").trim().slice(0,300), JSON.stringify(answers.map(a => String(a).trim().slice(0,2000))));
  res.json({ ok: true, id: info.lastInsertRowid });
});

app.get("/api/admin/applications", requireAdmin, (_, res) => {
  const rows = db.prepare("SELECT * FROM applications ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, id DESC").all();
  res.json(rows.map(r => ({ ...r, answers: JSON.parse(r.answers) })));
});
app.post("/api/admin/applications/:id/decision", requireAdmin, async (req, res) => {
  const status = req.body.status;
  if (!["accepted", "denied"].includes(status)) return res.status(400).json({ error: "Choose accepted or denied." });
  const item = db.prepare("SELECT * FROM applications WHERE id=?").get(Number(req.params.id));
  if (!item) return res.status(404).json({ error: "Application not found." });
  db.prepare("UPDATE applications SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(status, item.id);
  const transport = mailer();
  let emailSent = false, emailWarning = "";
  if (transport) {
    try {
      const accepted = status === "accepted";
      await transport.sendMail({
        from: process.env.MAIL_FROM || process.env.SMTP_USER, to: item.email,
        subject: accepted ? "Your application has been accepted" : "Update on your application",
        text: accepted
          ? `Hi ${item.name},\n\nGood news! Your ${item.type === "player" ? "team" : "partnership"} application has been accepted. The team will follow up with next steps.\n\nBest,\nTeam Admin`
          : `Hi ${item.name},\n\nThank you for your ${item.type === "player" ? "team" : "partnership"} application and your interest in working with us. Unfortunately, we are unable to accept it at this time.\n\nBest,\nTeam Admin`
      });
      emailSent = true;
    } catch (e) { emailWarning = "Decision saved, but email failed to send. Check SMTP settings."; }
  } else { emailWarning = "Decision saved, but email is not configured yet."; }
  res.json({ ok: true, status, emailSent, emailWarning });
});
app.post("/api/admin/roster", requireAdmin, (req, res) => {
  const { name, number, position, instagram, email } = req.body || {};
  if (!String(name || "").trim()) return res.status(400).json({ error: "Player name is required." });
  const info = db.prepare("INSERT INTO roster (name,number,position,instagram,email) VALUES (?,?,?,?,?)")
    .run(String(name).trim().slice(0,150), String(number || "").slice(0,10), String(position || "").slice(0,80), String(instagram || "").slice(0,300), String(email || "").slice(0,254));
  res.json({ ok: true, id: info.lastInsertRowid });
});
app.put("/api/admin/roster/:id", requireAdmin, (req, res) => {
  const { name, number, position, instagram, email } = req.body || {};
  if (!String(name || "").trim()) return res.status(400).json({ error: "Player name is required." });
  const result = db.prepare("UPDATE roster SET name=?,number=?,position=?,instagram=?,email=? WHERE id=?")
    .run(String(name).trim().slice(0,150), String(number || "").slice(0,10), String(position || "").slice(0,80), String(instagram || "").slice(0,300), String(email || "").slice(0,254), Number(req.params.id));
  res.json({ ok: result.changes > 0 });
});
app.delete("/api/admin/roster/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM roster WHERE id=?").run(Number(req.params.id)); res.json({ ok: true });
});
app.post("/api/admin/news", requireAdmin, (req, res) => {
  const { title, body } = req.body || {};
  if (!String(title || "").trim() || !String(body || "").trim()) return res.status(400).json({ error: "Title and news text are required." });
  const info = db.prepare("INSERT INTO news (title,body) VALUES (?,?)").run(String(title).trim().slice(0,200), String(body).trim().slice(0,3000));
  res.json({ ok: true, id: info.lastInsertRowid });
});
app.delete("/api/admin/news/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM news WHERE id=?").run(Number(req.params.id)); res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Team portal running at http://localhost:${PORT}`));
